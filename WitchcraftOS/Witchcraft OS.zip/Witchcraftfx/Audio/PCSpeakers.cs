﻿using System;

namespace WitchcraftOS.Witchcraftfx.Audio
{
    public static class PCSpeakers
    {
        public static void Beep(int frequency, int time)
        {

        }
    }
}
