﻿using System;
using System.Collections.Generic;

using Cosmos.Hardware;

namespace WitchcraftOS.Witchcraftfx.LangManagement
{
    public static class KeyLayout
    {
        
    }
}
