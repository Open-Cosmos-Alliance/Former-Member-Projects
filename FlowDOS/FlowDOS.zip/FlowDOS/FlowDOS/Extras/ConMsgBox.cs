﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS
{
    class ConMsgBox
    {
        public static void Show(string Text, ConsoleColor BackColor, ConsoleColor ForeColor)
        {

        }
    }
}
