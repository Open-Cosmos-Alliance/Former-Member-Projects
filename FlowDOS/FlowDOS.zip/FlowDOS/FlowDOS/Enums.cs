﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS
{

    /*
NoobOS, Copyright (C) 2012-2013 NoobOS
NoobOS and its tools come with ABSOLUTELY NO WARRANTY. This is free software,
and you are welcome to redistribute it under certain conditions, see
http://www.gnu.org/licenses/gpl-2.0.html for details.
*/

        public enum AccessRights
        {
            Everyone = 0,

            Administrator,

            User,
        }
    
}
