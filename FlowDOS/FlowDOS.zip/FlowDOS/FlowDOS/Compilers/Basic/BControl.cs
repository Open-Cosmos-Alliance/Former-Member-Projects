﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS.Compilers.Basic
{
    class BControl
    {
        //Wrote by: Matt, for the PearOs team.

        public string Control_Name;
        public type Control_Type;

        public enum type {
            TextBox,
            RichTextBox,
            Button
        };


    }
}
