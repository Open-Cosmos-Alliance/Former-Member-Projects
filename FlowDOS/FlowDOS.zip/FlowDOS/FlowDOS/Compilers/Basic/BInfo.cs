﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS.Compilers.Basic
{
    class BInfo
    {
        //Wrote by: Matt, for the PearOs team.

        public string Company = "default";
        public string Copyright = "default";
        public string Version = "default";
        public string MemoryTableSize = "40";
    }
}
