﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace iPear.Core.Screen.Login
{
    /*
EnvyOS (Pear OS) code, Copyright (C) 2010-2013 The EnvyOS (Pear OS) Project
This code comes with ABSOLUTELY NO WARRANTY. This is free software,
and you are welcome to redistribute it under certain conditions, see
http://www.gnu.org/licenses/gpl-2.0.html for details.
*/
    public static class Login
    {
        public static void DoLogin()
        {
        }
    }
}
