﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS
{
    class OldRandom
    {
        /*public static int Next(int min = 0, int max = 10)
        {
            int r = 0;
            if (Time.Seconds % 5 == 0)
            {
                r = Time.Seconds * 8 + 23 * (Cosmos.Hardware.RTC.Minute * 3);
                while (r > max)
                {
                    r = r - max;
                }
                return r;
            }
            else if (Time.Seconds % 2 == 0)
            {
                r = Time.Seconds * 4 + 13 * (Cosmos.Hardware.RTC.Minute * 81);
                while (r > max)
                {
                    r = r - max;
                }
                return r;
            }
            else if (Time.Seconds % 8 == 0)
            {
                r = Time.Seconds * 5 + 16 * (Cosmos.Hardware.RTC.Minute * 63);
                while (r > max)
                {
                    r = r - max;
                }
                return r;
            }
            else if (Time.Seconds % 8 == 0)
            {
                r = Time.Seconds * 5 + 16 * (Cosmos.Hardware.RTC.Minute * 63);
                while (r > max)
                {
                    r = r - max;
                }
                return r;
            }
        }*/
    }
}
