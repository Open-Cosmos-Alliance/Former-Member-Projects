﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS.Core
{
    public class Main
    {
        public void Init()
        {
            Console.WriteLine("FlowDOS started.");
        }
    }
}
