﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS
{
    public class Main2
    {
        static Core.Main mn = new Core.Main();
        public static void Init()
        {
            mn.Init();
        }
    }
}
