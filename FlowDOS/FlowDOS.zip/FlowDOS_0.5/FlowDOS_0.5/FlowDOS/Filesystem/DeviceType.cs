﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS.Filesystem
{
    public enum DeviceType
    {
        CharDevice = 1,
        BlockDevice = 2,
        Other = 3
    }
}
