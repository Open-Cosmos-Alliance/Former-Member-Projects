﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS.Core.GUI.VMwareSVGA
{
    class Main
    {
        FlowDOS.Drivers.Screen.VMwareSVGA scr = new FlowDOS.Drivers.Screen.VMwareSVGA();

        public void Init()
        {
        }
    }
}
