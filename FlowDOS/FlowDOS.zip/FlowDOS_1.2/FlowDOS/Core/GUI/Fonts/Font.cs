﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS.Core.GUI.Fonts
{
    public abstract class Font
    {
        public abstract int Width { get; }
        public abstract int Height { get; }
    }
}
