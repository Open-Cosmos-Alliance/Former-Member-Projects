﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowDOS.Core
{
    class System
    {
        public static string Name = "FlowDOS";
        public static int MajorVersion = 1;
        public static int MinorVersion = 2;
        public static string Version = MajorVersion + "." + MinorVersion;

        public static string CopyrightText = "Copyright (c) zDimension 2013";
    }
}
