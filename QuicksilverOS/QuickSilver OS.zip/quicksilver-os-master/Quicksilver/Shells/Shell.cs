﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Quicksilver.Shells
{
    public abstract class Shell
    {
        public abstract void Run();
    }
}
