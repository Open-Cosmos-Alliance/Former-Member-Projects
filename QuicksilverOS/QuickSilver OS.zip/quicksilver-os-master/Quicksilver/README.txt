Any distribution of GLNFSLib.dll MUST include License.txt AND this file.

