quicksilver-os
==============

Quicksilver is an elf32/bin operating system that is based on cosmos.